# ZFM-PRAK
Vzory pro praktika

VŠE PROSÍM PATŘIČNĚ CITUJTE!

Poznámky paní slečny Timey zde: https://www.overleaf.com/read/fjtqjxjdxxts

Váš Adam Červenka
